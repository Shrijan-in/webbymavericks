/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion, useScroll, useTransform, useSpring } from "motion/react";
import { useRef, useState, useEffect, RefObject } from "react";
import { ArrowRight, ChevronDown, Instagram, Twitter, Github, Menu, X, ArrowLeft, Mail, Phone, MapPin, ExternalLink } from "lucide-react";

const Navbar = ({ isDarkText, onBack, isWorkPage }: { isDarkText: boolean, onBack?: () => void, isWorkPage?: boolean }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const textColorClass = isDarkText ? "text-dark" : "text-white";
  const glassClass = isDarkText ? "bg-black/5 border-black/10" : "bg-white/5 border-white/10";

  return (
    <nav className={`fixed top-0 w-full z-50 transition-all duration-500 ${scrolled ? `py-4 backdrop-blur-lg border-b ${glassClass}` : "py-8"} ${textColorClass}`}>
      <div className="max-w-7xl mx-auto px-6 flex justify-between items-center">
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="text-2xl font-serif tracking-tighter cursor-pointer"
          onClick={onBack}
        >
          LUMINA
        </motion.div>
        
        {!isWorkPage ? (
          <div className="hidden md:flex gap-8 text-sm uppercase tracking-widest font-medium">
            {["Experience", "Gallery", "About", "Contact"].map((item, i) => (
              <motion.a
                key={item}
                href={`#${item.toLowerCase()}`}
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className="hover:text-gold transition-colors"
              >
                {item}
              </motion.a>
            ))}
          </div>
        ) : (
          <motion.button
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            onClick={onBack}
            className="flex items-center gap-2 text-sm uppercase tracking-widest font-medium hover:text-gold transition-colors"
          >
            <ArrowLeft className="w-4 h-4" /> Back to Home
          </motion.button>
        )}

        <div className="md:hidden">
          <button onClick={() => setIsOpen(!isOpen)}>
            {isOpen ? <X /> : <Menu />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && !isWorkPage && (
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="absolute top-full left-0 w-full bg-dark/95 backdrop-blur-xl p-8 flex flex-col gap-6 text-center border-b border-white/10 text-white"
        >
          {["Experience", "Gallery", "About", "Contact"].map((item) => (
            <a key={item} href={`#${item.toLowerCase()}`} onClick={() => setIsOpen(false)} className="text-xl font-serif">
              {item}
            </a>
          ))}
        </motion.div>
      )}
    </nav>
  );
};

const Hero = () => {
  const ref = useRef(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start start", "end start"]
  });

  const y = useTransform(scrollYProgress, [0, 1], ["0%", "50%"]);
  const opacity = useTransform(scrollYProgress, [0, 0.5], [1, 0]);
  const scale = useTransform(scrollYProgress, [0, 1], [1, 1.2]);

  return (
    <section ref={ref} id="experience" className="relative h-screen flex items-center justify-center overflow-hidden">
      <motion.div 
        style={{ y, scale }}
        className="absolute inset-0 z-0"
      >
        <img 
          src="https://picsum.photos/seed/lumina-hero/1920/1080?blur=2" 
          alt="Hero Background"
          className="w-full h-full object-cover opacity-40"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-dark/20 via-transparent to-dark" />
      </motion.div>

      <div className="relative z-10 text-center px-6">
        <motion.p 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="text-gold uppercase tracking-[0.5em] text-sm mb-6"
        >
          Redefining the digital horizon
        </motion.p>
        <motion.h1 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7, duration: 0.8 }}
          className="text-6xl md:text-9xl font-serif mb-8 tracking-tighter leading-none"
        >
          Beyond <br /> <span className="italic text-gradient">Perception</span>
        </motion.h1>
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.2 }}
          className="flex flex-col items-center gap-4"
        >
          <button className="group flex items-center gap-3 px-8 py-4 border border-white/20 rounded-full hover:bg-white hover:text-dark transition-all duration-500 uppercase tracking-widest text-xs">
            Begin Journey
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>
        </motion.div>
      </div>

      <motion.div 
        style={{ opacity }}
        animate={{ y: [0, 10, 0] }}
        transition={{ repeat: Infinity, duration: 2 }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2 text-white/30"
      >
        <ChevronDown className="w-8 h-8" />
      </motion.div>
    </section>
  );
};

interface GalleryItemProps {
  src: string;
  title: string;
  category: string;
  index: number;
  key?: number | string;
}

const GalleryItem = ({ src, title, category, index }: GalleryItemProps) => {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay: index * 0.1 }}
      className="group relative aspect-[4/5] overflow-hidden rounded-2xl cursor-pointer"
    >
      <img 
        src={src} 
        alt={title}
        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
        referrerPolicy="no-referrer"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-dark/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
      <div className="absolute bottom-0 left-0 p-8 translate-y-4 group-hover:translate-y-0 opacity-0 group-hover:opacity-100 transition-all duration-500">
        <p className="text-gold text-xs uppercase tracking-widest mb-2">{category}</p>
        <h3 className="text-2xl font-serif">{title}</h3>
      </div>
    </motion.div>
  );
};

const Gallery = ({ onViewAll }: { onViewAll: () => void }) => {
  const items = [
    { src: "https://picsum.photos/seed/art1/800/1000", title: "Ethereal Flow", category: "Digital Art" },
    { src: "https://picsum.photos/seed/art2/800/1000", title: "Midnight Echo", category: "Photography" },
    { src: "https://picsum.photos/seed/art3/800/1000", title: "Golden Hour", category: "Architecture" },
    { src: "https://picsum.photos/seed/art4/800/1000", title: "Silent Peak", category: "Nature" },
  ];

  return (
    <section id="gallery" className="py-32 px-6 max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-8">
        <div>
          <h2 className="text-4xl md:text-6xl mb-4">Curated <span className="italic">Visions</span></h2>
          <p className="text-white/50 max-w-md">A collection of moments captured in the intersection of light and shadow.</p>
        </div>
        <button 
          onClick={onViewAll}
          className="text-gold uppercase tracking-widest text-xs border-b border-gold/30 pb-2 hover:border-gold transition-all"
        >
          View All Works
        </button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {items.map((item, i) => (
          <GalleryItem key={i} src={item.src} title={item.title} category={item.category} index={i} />
        ))}
      </div>
    </section>
  );
};

const WorkPage = () => {
  const projects = [
    { src: "https://picsum.photos/seed/p1/800/1000", title: "Nebula Dreams", category: "Digital Art", year: "2024" },
    { src: "https://picsum.photos/seed/p2/800/1000", title: "Urban Pulse", category: "Photography", year: "2023" },
    { src: "https://picsum.photos/seed/p3/800/1000", title: "Zenith Tower", category: "Architecture", year: "2024" },
    { src: "https://picsum.photos/seed/p4/800/1000", title: "Oceanic Whisper", category: "Nature", year: "2023" },
    { src: "https://picsum.photos/seed/p5/800/1000", title: "Cyber Soul", category: "Digital Art", year: "2024" },
    { src: "https://picsum.photos/seed/p6/800/1000", title: "Neon Nights", category: "Photography", year: "2024" },
    { src: "https://picsum.photos/seed/p7/800/1000", title: "Crystal Cave", category: "Nature", year: "2022" },
    { src: "https://picsum.photos/seed/p8/800/1000", title: "Void Space", category: "Architecture", year: "2024" },
  ];

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="pt-32 pb-20 px-6 max-w-7xl mx-auto"
    >
      <div className="mb-20">
        <motion.h1 
          initial={{ y: 30, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="text-6xl md:text-8xl font-serif mb-8"
        >
          Our <span className="italic">Portfolio</span>
        </motion.h1>
        <motion.p 
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="text-white/50 text-xl max-w-2xl"
        >
          A deep dive into our most impactful projects, showcasing our commitment to visual excellence and technical mastery.
        </motion.p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {projects.map((project, i) => (
          <motion.div 
            key={i}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.05 }}
            className="group cursor-pointer"
          >
            <div className="aspect-[3/4] overflow-hidden rounded-3xl mb-6 relative">
              <img 
                src={project.src} 
                alt={project.title}
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-dark/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <ExternalLink className="w-10 h-10 text-white" />
              </div>
            </div>
            <div className="flex justify-between items-start">
              <div>
                <h3 className="text-2xl font-serif mb-1">{project.title}</h3>
                <p className="text-white/40 text-sm uppercase tracking-widest">{project.category}</p>
              </div>
              <span className="text-gold font-mono text-sm">{project.year}</span>
            </div>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
};

const About = ({ aboutRef }: { aboutRef: RefObject<HTMLDivElement | null> }) => {
  return (
    <section ref={aboutRef} id="about" className="py-32 bg-white text-dark overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
        <div className="relative">
          <motion.div 
            initial={{ scale: 0.8, opacity: 0 }}
            whileInView={{ scale: 1, opacity: 1 }}
            viewport={{ once: true }}
            className="aspect-square rounded-full overflow-hidden border-[20px] border-dark/5"
          >
            <img 
              src="https://picsum.photos/seed/about/1000/1000" 
              alt="About Lumina"
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </motion.div>
          <motion.div 
            animate={{ rotate: 360 }}
            transition={{ repeat: Infinity, duration: 20, ease: "linear" }}
            className="absolute -top-10 -right-10 w-40 h-40 border border-dark/10 rounded-full flex items-center justify-center text-[10px] uppercase tracking-[0.3em] font-bold"
          >
            <div className="text-center">
              Crafting <br /> Excellence <br /> Since 2024
            </div>
          </motion.div>
        </div>

        <div>
          <motion.h2 
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="text-5xl md:text-7xl mb-10 leading-tight"
          >
            We believe in the power of <span className="italic font-serif">Aesthetics</span>.
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="text-xl text-dark/70 mb-12 leading-relaxed"
          >
            Lumina is a creative studio dedicated to pushing the boundaries of digital interaction. 
            We blend technical precision with artistic intuition to create experiences that resonate 
            deeply with the human spirit.
          </motion.p>
          <div className="grid grid-cols-2 gap-8">
            <div>
              <h4 className="font-bold text-3xl mb-2">150+</h4>
              <p className="text-sm uppercase tracking-widest text-dark/50">Projects Completed</p>
            </div>
            <div>
              <h4 className="font-bold text-3xl mb-2">24</h4>
              <p className="text-sm uppercase tracking-widest text-dark/50">Design Awards</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const Contact = () => {
  return (
    <section id="contact" className="py-32 px-6 max-w-7xl mx-auto border-t border-white/10">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-20">
        <div>
          <h2 className="text-5xl md:text-7xl mb-8 leading-tight">
            Let's create something <span className="italic">extraordinary</span>.
          </h2>
          <p className="text-white/50 text-xl mb-12 max-w-md">
            Whether you have a specific project in mind or just want to explore possibilities, we're here to help.
          </p>
          
          <div className="space-y-8">
            <div className="flex items-start gap-6">
              <div className="w-12 h-12 rounded-full glass flex items-center justify-center flex-shrink-0">
                <Mail className="w-5 h-5 text-gold" />
              </div>
              <div>
                <h4 className="text-sm uppercase tracking-widest text-white/40 mb-1">Email Us</h4>
                <p className="text-xl">hello@lumina.studio</p>
              </div>
            </div>
            <div className="flex items-start gap-6">
              <div className="w-12 h-12 rounded-full glass flex items-center justify-center flex-shrink-0">
                <Phone className="w-5 h-5 text-gold" />
              </div>
              <div>
                <h4 className="text-sm uppercase tracking-widest text-white/40 mb-1">Call Us</h4>
                <p className="text-xl">+1 (555) 000-1234</p>
              </div>
            </div>
            <div className="flex items-start gap-6">
              <div className="w-12 h-12 rounded-full glass flex items-center justify-center flex-shrink-0">
                <MapPin className="w-5 h-5 text-gold" />
              </div>
              <div>
                <h4 className="text-sm uppercase tracking-widest text-white/40 mb-1">Visit Us</h4>
                <p className="text-xl">77 Design District, Creative Valley, CA</p>
              </div>
            </div>
          </div>
        </div>

        <motion.div 
          initial={{ opacity: 0, x: 30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          className="glass p-10 rounded-3xl"
        >
          <form className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-xs uppercase tracking-widest text-white/40">Full Name</label>
                <input type="text" className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-gold transition-colors" placeholder="John Doe" />
              </div>
              <div className="space-y-2">
                <label className="text-xs uppercase tracking-widest text-white/40">Email Address</label>
                <input type="email" className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-gold transition-colors" placeholder="john@example.com" />
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-xs uppercase tracking-widest text-white/40">Subject</label>
              <select className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-gold transition-colors appearance-none">
                <option className="bg-dark">New Project Inquiry</option>
                <option className="bg-dark">Partnership</option>
                <option className="bg-dark">Career Opportunities</option>
                <option className="bg-dark">General Question</option>
              </select>
            </div>
            <div className="space-y-2">
              <label className="text-xs uppercase tracking-widest text-white/40">Message</label>
              <textarea rows={4} className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-gold transition-colors resize-none" placeholder="Tell us about your vision..."></textarea>
            </div>
            <button className="w-full bg-gold text-dark font-bold py-4 rounded-xl hover:bg-white transition-colors duration-500 uppercase tracking-[0.2em] text-sm">
              Send Message
            </button>
          </form>
        </motion.div>
      </div>
    </section>
  );
};

const Footer = () => {
  return (
    <footer className="py-10 px-6 border-t border-white/5 bg-dark/50">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-8">
        <div className="flex gap-8">
          <a href="#" className="hover:text-gold transition-colors"><Instagram className="w-5 h-5" /></a>
          <a href="#" className="hover:text-gold transition-colors"><Twitter className="w-5 h-5" /></a>
          <a href="#" className="hover:text-gold transition-colors"><Github className="w-5 h-5" /></a>
        </div>

        <div className="text-white/20 text-[10px] uppercase tracking-[0.3em] font-medium">
          &copy; 2026 LUMINA CREATIVE STUDIO. ALL RIGHTS RESERVED.
        </div>
        
        <div className="flex gap-6 text-[10px] uppercase tracking-widest text-white/40 font-medium">
          <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
          <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
        </div>
      </div>
    </footer>
  );
};

const CursorCamera = () => {
  const mouseX = useSpring(0, { stiffness: 50, damping: 20 });
  const mouseY = useSpring(0, { stiffness: 50, damping: 20 });
  const rotateX = useSpring(0, { stiffness: 50, damping: 20 });
  const rotateY = useSpring(0, { stiffness: 50, damping: 20 });
  const [isHovering, setIsHovering] = useState(false);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      mouseX.set(e.clientX);
      mouseY.set(e.clientY);

      // Calculate rotation based on screen position
      const xPct = (e.clientX / window.innerWidth - 0.5) * 60;
      const yPct = (e.clientY / window.innerHeight - 0.5) * -60;
      rotateX.set(yPct);
      rotateY.set(xPct);

      // Check if hovering over interactive element
      const target = e.target as HTMLElement;
      const isInteractive = target.closest('button, a, input, [role="button"]');
      setIsHovering(!!isInteractive);
    };

    window.addEventListener("mousemove", handleMouseMove);
    return () => window.removeEventListener("mousemove", handleMouseMove);
  }, [mouseX, mouseY, rotateX, rotateY]);

  return (
    <motion.div
      style={{
        x: mouseX,
        y: mouseY,
        translateX: "-50%",
        translateY: "-50%",
        scale: isHovering ? 1.5 : 1,
      }}
      transition={{ type: "spring", stiffness: 300, damping: 20 }}
      className="fixed top-0 left-0 pointer-events-none z-[100] hidden lg:flex items-center justify-center"
    >
      {/* Precision Dot */}
      <div className="absolute w-1 h-1 bg-gold rounded-full z-10" />

      <motion.div
        style={{
          rotateX,
          rotateY,
          perspective: 1000,
        }}
        className="relative flex items-center justify-center p-10"
      >
        {/* Camera Body */}
        <div className="w-12 h-8 bg-gold/20 backdrop-blur-md border border-gold/40 rounded-lg flex items-center justify-center shadow-[0_0_20px_rgba(212,175,55,0.2)]">
          {/* Lens */}
          <div className="w-4 h-4 rounded-full bg-dark border-2 border-gold/60 flex items-center justify-center overflow-hidden">
            <div className="w-1 h-1 bg-white/40 rounded-full translate-x-0.5 -translate-y-0.5" />
          </div>
          {/* Flash/Detail */}
          <div className="absolute -top-1 right-2 w-3 h-1 bg-gold/60 rounded-full" />
        </div>
        
        {/* Viewfinder/Top */}
        <div className="absolute -top-2 left-3 w-4 h-2 bg-gold/40 rounded-t-sm" />

        {/* Dynamic Glow */}
        <motion.div 
          animate={{ opacity: [0.2, 0.5, 0.2] }}
          transition={{ repeat: Infinity, duration: 2 }}
          className="absolute inset-0 bg-gold/10 blur-xl rounded-full" 
        />
      </motion.div>
    </motion.div>
  );
};

export default function App() {
  const { scrollYProgress } = useScroll();
  const aboutRef = useRef<HTMLDivElement>(null);
  const [isAboutInView, setIsAboutInView] = useState(false);
  const [view, setView] = useState<'home' | 'work'>('home');

  const scaleX = useSpring(scrollYProgress, {
    stiffness: 100,
    damping: 30,
    restDelta: 0.001
  });

  useEffect(() => {
    if (view === 'work') {
      window.scrollTo(0, 0);
      setIsAboutInView(false);
      return;
    }

    const observer = new IntersectionObserver(
      ([entry]) => {
        setIsAboutInView(entry.isIntersecting);
      },
      { 
        threshold: 0.1,
        rootMargin: "-80px 0px -50% 0px"
      }
    );

    if (aboutRef.current) {
      observer.observe(aboutRef.current);
    }

    return () => observer.disconnect();
  }, [view]);

  return (
    <main className="relative">
      <CursorCamera />
      {/* Progress Bar */}
      <motion.div 
        className="fixed top-0 left-0 right-0 h-1 bg-gold z-[60] origin-left"
        style={{ scaleX }}
      />

      <Navbar 
        isDarkText={isAboutInView} 
        isWorkPage={view === 'work'} 
        onBack={() => setView('home')} 
      />
      
      {view === 'home' ? (
        <>
          <Hero />
          <Gallery onViewAll={() => setView('work')} />
          <About aboutRef={aboutRef} />
          <Contact />
          <Footer />
        </>
      ) : (
        <WorkPage />
      )}
    </main>
  );
}
